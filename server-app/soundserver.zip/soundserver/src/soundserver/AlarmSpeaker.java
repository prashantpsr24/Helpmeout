package soundserver;

import sun.audio.*;

import java.io.*;
import java.net.Socket;


 
public class AlarmSpeaker
{
	AudioStream audioStream;
	private boolean status=true;
  public static void main(String[] args) 
  {
	  try
      {
	   	int port=6070;
         Thread t = new NetworkModule(port);
         t.start();
         
      }
   catch(IOException e)
      {
         e.printStackTrace();
      }
  }
  
  public void playSound() 
  {
    try
    {
      // get the sound file as a resource out of my jar file;
      // the sound file must be in the same directory as this class file.
      // the input stream portion of this recipe comes from a javaworld.com article.
    	System.out.println("Trying");
    	InputStream inputStream = getClass().getResourceAsStream("husten.wav");
    	System.out.println(inputStream);
    	audioStream = new AudioStream(inputStream);
    	
    	
    		AudioPlayer.player.start(audioStream);
        	System.out.println("Done");

    }
    catch (Exception e)
    {
    	 System.out.println("Tried2");
      // a special way i'm handling logging in this application
      e.printStackTrace();
    }
  }
  
  public void stopSound() 
  {
    try
    {
      status = false;
      AudioPlayer.player.stop(audioStream);
      
    }
    catch (Exception e)
    {
    	 System.out.println("Tried2");
      // a special way i'm handling logging in this application
      e.printStackTrace();
    }
  }
}